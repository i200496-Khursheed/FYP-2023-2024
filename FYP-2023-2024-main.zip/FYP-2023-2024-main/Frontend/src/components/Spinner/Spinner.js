// Spinner.js
import React from 'react';
import './Spinner.css'; // Add CSS for spinner styling

const Spinner = () => {
  return <div className="spinner"></div>;
};

export default Spinner;
