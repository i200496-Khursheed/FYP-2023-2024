//PeoplePage.js
import React from 'react';
import People from '../components/People/People';

function PeoplePage() {
  return (
    <div>
      <People />
    </div>
  );
}

export default PeoplePage;
