//FAQPage.js
import React from 'react';
import FAQ from '../components/FAQ/FAQ';

function FAQPage() {
  return (
    <div>
      <FAQ />
    </div>
  );
}

export default FAQPage;
