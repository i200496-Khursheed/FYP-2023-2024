//FAQResultsPage.js
import React from 'react';
import FAQResults from '../components/FAQResults/FAQResults';

function FAQResultsPage() {
  return (
    <div>
      <FAQResults />
    </div>
  );
}

export default FAQResultsPage;
