//GraphPage.js
import React from 'react';
import XMLRenderer from '../components/Graph/Graph';

function GraphPage() {
  return (
    <div>
      <XMLRenderer />
    </div>
  );
}

export default GraphPage;
