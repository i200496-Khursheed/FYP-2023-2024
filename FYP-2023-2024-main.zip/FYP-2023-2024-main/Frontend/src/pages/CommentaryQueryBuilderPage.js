//CommentaryQueryBuilderPage.js
import React from 'react';
import CommentaryQueryBuilder from '../components/CommentaryQueryBuilder/CommentaryQueryBuilder';

function CommentaryQueryBuilderPage() {
  return (
    <div>
      <CommentaryQueryBuilder />
    </div>
  );
}

export default CommentaryQueryBuilderPage;
