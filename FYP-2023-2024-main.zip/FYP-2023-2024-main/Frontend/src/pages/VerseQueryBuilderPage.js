//VerseQueryBuilderPage.js
import React from 'react';
import VerseQueryBuilder from '../components/VerseQueryBuilder/VerseQueryBuilder';

function VerseQueryBuilderPage() {
  return (
    <div>
      <VerseQueryBuilder />
    </div>
  );
}

export default VerseQueryBuilderPage;
