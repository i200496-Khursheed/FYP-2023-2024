//ChainPage.js
import React from 'react';
import Chain from '../components/Chain/Chain';

function ChainPage() {
  return (
    <div>
      <Chain />
    </div>
  );
}

export default ChainPage;
