// import Navbar from '../components/Navbar/Navbar';
// import Footer from '../components/Footer/Footer';
import MainContent from '../components/MainContent/MainContent';

function LandingPage() {
  return (
    <div>
      <MainContent />
    </div>
  );
}

export default LandingPage;
