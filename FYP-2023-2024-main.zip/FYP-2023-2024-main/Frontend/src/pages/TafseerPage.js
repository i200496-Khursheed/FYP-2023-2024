//PeoplePage.js
import React from 'react';
import XMLRenderer from '../components/Tafseer/Tafseer';

function TafseerPage() {
  return (
    <div>
      <XMLRenderer />
    </div>
  );
}

export default TafseerPage;
