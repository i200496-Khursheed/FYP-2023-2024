//HadithQueryBuilderPage.js
import React from 'react';
import HadithQueryBuilder from '../components/HadithQueryBuilder/HadithQueryBuilder';

function HadithQueryBuilderPage() {
  return (
    <div>
      <HadithQueryBuilder />
    </div>
  );
}

export default HadithQueryBuilderPage;
