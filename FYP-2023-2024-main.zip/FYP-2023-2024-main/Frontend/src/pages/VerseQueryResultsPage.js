//VerseQueryResultsPage.js
import React from 'react';
import VerseQueryResults from '../components/VerseQueryResults/VerseQueryResults';

function VerseQueryResultsPage() {
  return (
    <div>
      <VerseQueryResults />
    </div>
  );
}

export default VerseQueryResultsPage;
