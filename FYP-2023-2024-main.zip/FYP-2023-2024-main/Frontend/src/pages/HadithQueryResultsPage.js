//HadithQueryResultsPage.js
import React from 'react';
import HadithQueryResults from '../components/HadithQueryResults/HadithQueryResults';

function HadithQueryResultsPage() {
  return (
    <div>
      <HadithQueryResults />
    </div>
  );
}

export default HadithQueryResultsPage;
