//CommentaryQueryResultsPage.js
import React from 'react';
import CommentaryQueryResults from '../components/CommentaryQueryResults/CommentaryQueryResults';

function CommentaryQueryResultsPage() {
  return (
    <div>
      <CommentaryQueryResults />
    </div>
  );
}

export default CommentaryQueryResultsPage;
