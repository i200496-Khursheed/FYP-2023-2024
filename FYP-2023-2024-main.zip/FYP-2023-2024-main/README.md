# FYP-2023-2024
Knowledge Driven Semantic Web Portal for Tafseer-Al-Tabari
